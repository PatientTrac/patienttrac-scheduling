import { useState, useEffect } from 'react'

const SUPABASE_URL = 'https://mskormozwekezjmtcylv.supabase.co'
const ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1za29ybW96d2VrZXpqbXRjeWx2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY5NzMzMzAsImV4cCI6MjA5MjU0OTMzMH0.nO9Q31CZJWRSIieLdLYVMkdu5NDDWjf1z0TgwCjBpp0'
const BRIDGE = `${SUPABASE_URL}/functions/v1/cross-app-bridge`

async function bridge(action: string, body: Record<string, any> = {}) {
  const res = await fetch(BRIDGE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', apikey: ANON_KEY },
    body: JSON.stringify({ action, ...body }),
  })
  return res.json()
}

const s: Record<string, React.CSSProperties> = {
  shell:  { minHeight:'100vh', background:'#020a14', color:'#e8eaf0', fontFamily:"'DM Sans',sans-serif" },
  center: { display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', minHeight:'100vh' },
  spin:   { width:32, height:32, border:'3px solid #3a4a6a', borderTopColor:'#00d4ff', borderRadius:'50%', animation:'spin 1s linear infinite' },
  errBox: { maxWidth:480, margin:'80px auto', padding:32, background:'#0a1628', border:'1px solid rgba(255,107,107,0.3)' },
  hdr:    { background:'#060e1c', borderBottom:'1px solid rgba(0,212,255,0.12)', padding:'12px 24px', display:'flex', alignItems:'center', justifyContent:'space-between' },
  badge:  { background:'rgba(0,212,255,0.15)', color:'#00d4ff', border:'1px solid rgba(0,212,255,0.3)', padding:'4px 10px', fontSize:11, fontWeight:700, letterSpacing:'0.12em', fontFamily:'DM Mono,monospace' },
  pname:  { fontSize:20, fontWeight:600, fontFamily:'Rajdhani,sans-serif', letterSpacing:'0.02em' },
  meta:   { fontSize:12, color:'#8a9bc0', marginTop:2 },
  tabs:   { display:'flex', borderBottom:'1px solid rgba(0,212,255,0.1)', background:'#060e1c' },
  tab:    { padding:'12px 22px', background:'transparent', border:'none', borderBottom:'2px solid transparent', color:'#3a4a6a', cursor:'pointer', fontSize:12, fontFamily:'DM Mono,monospace', letterSpacing:'0.06em', textTransform:'uppercase' },
  tabOn:  { color:'#00d4ff', borderBottomColor:'#00d4ff' },
  body:   { padding:24 },
  grid:   { display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:16 },
  card:   { background:'rgba(10,22,40,0.8)', border:'1px solid rgba(0,212,255,0.1)', padding:20 },
  cttl:   { fontSize:10, fontFamily:'DM Mono,monospace', color:'#00d4ff', letterSpacing:'0.12em', textTransform:'uppercase', marginBottom:10 },
  cbdy:   { fontSize:14, color:'#8a9bc0', lineHeight:1.6 },
  form:   { maxWidth:720, display:'flex', flexDirection:'column', gap:18 },
  row:    { display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 },
  fg:     { display:'flex', flexDirection:'column', gap:6 },
  lbl:    { fontSize:10, fontFamily:'DM Mono,monospace', color:'#3a4a6a', letterSpacing:'0.1em', textTransform:'uppercase' },
  inp:    { background:'rgba(6,14,28,0.8)', border:'1px solid rgba(0,212,255,0.15)', color:'#e8eaf0', padding:'10px 14px', fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:'none', width:'100%' },
  ta:     { background:'rgba(6,14,28,0.8)', border:'1px solid rgba(0,212,255,0.15)', color:'#e8eaf0', padding:'12px 14px', fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:'none', resize:'vertical', lineHeight:1.6, width:'100%' },
  btn:    { background:'rgba(0,212,255,0.15)', color:'#00d4ff', border:'1px solid rgba(0,212,255,0.4)', padding:'12px 28px', fontSize:12, fontFamily:'DM Mono,monospace', letterSpacing:'0.12em', textTransform:'uppercase', cursor:'pointer', fontWeight:500, alignSelf:'flex-start' },
  btnOff: { background:'rgba(0,212,255,0.05)', color:'rgba(0,212,255,0.3)', border:'1px solid rgba(0,212,255,0.1)', padding:'12px 28px', fontSize:12, fontFamily:'DM Mono,monospace', letterSpacing:'0.12em', textTransform:'uppercase', cursor:'not-allowed', fontWeight:500, alignSelf:'flex-start' },
  ok:     { background:'rgba(74,222,128,0.08)', border:'1px solid rgba(74,222,128,0.2)', color:'#4ade80', padding:'8px 16px', marginBottom:16, fontSize:13 },
  err:    { background:'rgba(255,107,107,0.08)', border:'1px solid rgba(255,107,107,0.2)', color:'#ff6b6b', padding:'8px 16px', marginBottom:16, fontSize:13 },
  closeBtn:{ background:'rgba(255,107,107,0.1)', border:'1px solid rgba(255,107,107,0.3)', color:'#ff6b6b', padding:'6px 16px', cursor:'pointer', fontSize:12, fontFamily:'DM Mono,monospace', letterSpacing:'0.08em' },
  muted:  { color:'#3a4a6a', fontSize:13 },
  encTag: { fontSize:11, background:'rgba(201,169,110,0.1)', color:'#c9a96e', padding:'3px 8px', fontFamily:'DM Mono,monospace' },
  mse:    { display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 },
  mseItem:{ display:'flex', flexDirection:'column', gap:4 },
}

const MSE_FIELDS = [
  ['appearance','Appearance'],['behavior','Behavior'],['speech','Speech'],['mood','Mood'],
  ['affect','Affect'],['thought_process','Thought Process'],['thought_content','Thought Content'],
  ['perception','Perception'],['cognition','Cognition'],['insight','Insight / Judgment'],
]

const MOOD_OPTS   = ['Euthymic','Depressed','Elevated','Anxious','Irritable','Mixed','Labile']
const AFFECT_OPTS = ['Full range','Restricted','Blunted','Flat','Congruent','Incongruent','Labile']
const APP_OPTS    = ['Well-groomed','Disheveled','Age-appropriate','Appears stated age','Malodorous']
const BEH_OPTS    = ['Cooperative','Agitated','Hostile','Guarded','Withdrawn','Psychomotor retardation','Psychomotor agitation']
const SPK_OPTS    = ['Normal rate/rhythm','Pressured','Slow','Monotone','Tangential','Circumstantial']
const TP_OPTS     = ['Linear and goal-directed','Tangential','Circumstantial','Flight of ideas','Loose associations','Thought blocking']
const TC_OPTS     = ['No AH/VH/SI/HI','Suicidal ideation','Homicidal ideation','Auditory hallucinations','Visual hallucinations','Paranoid ideation','Delusions']
const PERC_OPTS   = ['No perceptual disturbances','Auditory hallucinations','Visual hallucinations','Illusions','Depersonalization']
const COG_OPTS    = ['Intact orientation','Impaired attention','Memory deficits','Executive dysfunction','Alert and oriented x4']
const INS_OPTS    = ['Good insight and judgment','Limited insight','Poor insight','Intact judgment','Impaired judgment']

const FIELD_OPTS: Record<string,string[]> = {
  appearance:APP_OPTS, behavior:BEH_OPTS, speech:SPK_OPTS, mood:MOOD_OPTS,
  affect:AFFECT_OPTS, thought_process:TP_OPTS, thought_content:TC_OPTS,
  perception:PERC_OPTS, cognition:COG_OPTS, insight:INS_OPTS,
}

const DSM5_COMMON = [
  'F32.1 Major depressive disorder, single episode, moderate',
  'F33.1 Major depressive disorder, recurrent, moderate',
  'F41.1 Generalized anxiety disorder',
  'F40.10 Social anxiety disorder',
  'F43.10 PTSD',
  'F31.81 Bipolar II disorder',
  'F20.9 Schizophrenia',
  'F90.0 ADHD, predominantly inattentive',
  'F90.2 ADHD, combined presentation',
  'F60.3 Borderline personality disorder',
  'F10.20 Alcohol use disorder, moderate',
  'F84.0 Autism spectrum disorder',
]

export default function MentalHealthApp() {
  const [token]  = useState(() => new URLSearchParams(location.search).get('token') ?? '')
  const [sess,   setSess]  = useState<any>(null)
  const [enc,    setEnc]   = useState<any>(null)
  const [intake, setIntake]= useState<any>(null)
  const [meds,   setMeds]  = useState<any[]>([])
  const [tab,    setTab]   = useState<'chart'|'mse'|'em'|'careplan'>('chart')
  const [saving, setSaving]= useState(false)
  const [saved,  setSaved] = useState(false)
  const [error,  setError] = useState('')
  const [loading,setLoading]=useState(true)

  // MSE state
  const [mse, setMse] = useState<Record<string,string>>(Object.fromEntries(MSE_FIELDS.map(([k])=>[k,''])))
  const [mseExtra, setMseExtra] = useState({ safety_assessment:'', suicide_risk_level:'low', homicide_risk:'no', command_hallucinations:'no', assessment_notes:'' })

  // E&M note state
  const [em, setEm] = useState({ diagnosis:'', em_code:'99213', assessment:'', plan:'', medications_reviewed:true, safety_plan_reviewed:false })

  // Care plan state
  const [cp, setCp] = useState({ goals:'', interventions:'', target_date:'', frequency:'Weekly', modality:'Individual therapy' })

  useEffect(() => {
    if (!token) { setError('No session token. Access from PatientTracForge scheduling.'); setLoading(false); return }
    bridge('get_encounter', { token }).then(d => {
      if (d.error) { setError(d.error); setLoading(false); return }
      setSess(d.session); setEnc(d.encounter); setIntake(d.intake); setMeds(d.medications ?? [])
      if (d.encounter?.mood) setMse(m => ({...m, mood: d.encounter.mood, affect: d.encounter.affect || ''}))
      if (d.encounter?.em_diagnosis) setEm(e => ({...e, diagnosis: d.encounter.em_diagnosis, assessment: d.encounter.assessment || ''}))
      if (d.encounter?.goals) setCp(c => ({...c, goals: d.encounter.goals}))
      setLoading(false)
    }).catch(e => { setError(String(e)); setLoading(false) })
  }, [token])

  async function save(type: string, data: any) {
    setSaving(true); setSaved(false); setError('')
    const r = await bridge('save_note', { token, note_type: type, note_data: data })
    setSaving(false)
    if (r.success) { setSaved(true); setTimeout(() => setSaved(false), 3000) }
    else setError(r.error ?? 'Save failed')
  }

  async function closeEnc() {
    if (!confirm('Close this encounter and send to billing AI?')) return
    await bridge('callback', { token, event_type:'encounter_closed', payload:{closed_by:'mental_health'} })
    alert('Encounter closed. Billing AI running in PatientTracForge.'); window.close()
  }

  if (loading) return <div style={s.shell}><div style={s.center}><div style={s.spin}/><div style={{...s.muted,marginTop:12}}>Loading encounter...</div></div></div>
  if (error && !sess) return <div style={s.shell}><div style={s.errBox}><div style={{fontSize:18,fontWeight:600,color:'#ff6b6b',marginBottom:8}}>⚠ Access Error</div><div style={s.cbdy}>{error}</div><div style={{...s.muted,marginTop:12,fontSize:12}}>Access this app from PatientTracForge → Check-In → Route to Mental Health.</div></div></div>

  const pat = sess?.patient; const prov = sess?.provider

  return (
    <div style={s.shell}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}} *{box-sizing:border-box} select,input,textarea{color:#e8eaf0!important} select option{background:#060e1c}`}</style>
      <div style={s.hdr}>
        <div style={{display:'flex',alignItems:'center',gap:16}}>
          <div style={s.badge}>✦ MENTAL HEALTH</div>
          <div>
            <div style={s.pname}>{pat?.last_name}, {pat?.first_name}</div>
            <div style={s.meta}>DOB: {pat?.dob ? new Date(pat.dob).toLocaleDateString():'—'} · {pat?.gender} · #{sess?.patient_id}</div>
          </div>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{fontSize:11,color:'#8a9bc0',fontFamily:'DM Mono,monospace'}}>Dr. {prov?.last_name} · {prov?.specialty}</div>
          <div style={s.encTag}>Enc #{sess?.encounter_id}</div>
          <div style={{width:8,height:8,borderRadius:'50%',background:enc?.status==='open'?'#4ade80':'#f59e0b'}}/>
          <button onClick={closeEnc} style={s.closeBtn}>Close Encounter</button>
        </div>
      </div>

      <div style={s.tabs}>
        {([['chart','Patient Chart'],['mse','Mental Status Exam'],['em','E&M Note'],['careplan','Care Plan']] as const).map(([k,l]) => (
          <button key={k} onClick={() => setTab(k)} style={{...s.tab,...(tab===k?s.tabOn:{})}}>{l}</button>
        ))}
      </div>

      <div style={s.body}>
        {error && <div style={s.err}>{error}</div>}
        {saved && <div style={s.ok}>✓ Saved — synced to PatientTracForge scheduling</div>}

        {/* CHART */}
        {tab==='chart' && (
          <div style={s.grid}>
            <div style={s.card}><div style={s.cttl}>Chief Complaint</div><div style={s.cbdy}>{enc?.chief_complaint || intake?.chief_complaint || '—'}</div></div>
            {intake && (
              <div style={s.card}>
                <div style={s.cttl}>AI Intake Summary</div>
                <div style={s.cbdy}>{intake.ai_summary||'—'}</div>
                {intake.triage_level && <div style={{marginTop:8,display:'inline-block',padding:'3px 8px',fontSize:11,background: intake.triage_level==='emergent'?'rgba(255,68,68,0.15)':'rgba(251,191,36,0.15)', color: intake.triage_level==='emergent'?'#ff4444':'#fbbf24'}}>Triage: {intake.triage_level}</div>}
                {intake.suggested_icd_codes?.length > 0 && <div style={{...s.muted,marginTop:8,fontSize:12}}>Suggested: {intake.suggested_icd_codes.join(', ')}</div>}
              </div>
            )}
            <div style={s.card}><div style={s.cttl}>Allergies</div><div style={s.cbdy}>{pat?.allergies||'NKDA'}</div></div>
            <div style={s.card}>
              <div style={s.cttl}>Medications ({meds.length})</div>
              {meds.length===0 ? <div style={s.muted}>No current medications</div>
                : meds.map((m:any,i:number) => <div key={i} style={{fontSize:13,color:'#8a9bc0',padding:'4px 0',borderBottom:'1px solid rgba(255,255,255,0.04)'}}><strong style={{color:'#e8eaf0'}}>{m.medication_name}</strong> {m.dosage} — {m.frequency}</div>)}
            </div>
            <div style={s.card}><div style={s.cttl}>Diagnoses</div><div style={s.cbdy}>{enc?.em_diagnosis||'No prior diagnosis on file'}</div></div>
            <div style={s.card}><div style={s.cttl}>Contact / Emergency</div><div style={s.cbdy}>{pat?.phone}<br/>{pat?.email}</div></div>
          </div>
        )}

        {/* MENTAL STATUS EXAM */}
        {tab==='mse' && (
          <div style={s.form}>
            <div style={{...s.mse}}>
              {MSE_FIELDS.map(([key, label]) => (
                <div key={key} style={s.mseItem}>
                  <label style={s.lbl}>{label}</label>
                  <select value={mse[key]} onChange={e => setMse(m => ({...m,[key]:e.target.value}))} style={s.inp}>
                    <option value="">Select...</option>
                    {(FIELD_OPTS[key]||[]).map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              ))}
            </div>

            <div style={{background:'rgba(255,107,107,0.05)',border:'1px solid rgba(255,107,107,0.15)',padding:20}}>
              <div style={{...s.cttl,color:'#ff6b6b',marginBottom:16}}>⚠ Safety Assessment</div>
              <div style={s.row}>
                <div style={s.fg}>
                  <label style={s.lbl}>Suicide Risk Level</label>
                  <select value={mseExtra.suicide_risk_level} onChange={e=>setMseExtra(m=>({...m,suicide_risk_level:e.target.value}))} style={{...s.inp,borderColor:'rgba(255,107,107,0.3)'}}>
                    <option value="none">No ideation</option><option value="low">Low — passive ideation</option>
                    <option value="moderate">Moderate — ideation, no plan</option><option value="high">High — plan present</option>
                    <option value="imminent">Imminent — intent to act</option>
                  </select>
                </div>
                <div style={s.fg}>
                  <label style={s.lbl}>Homicidal Ideation</label>
                  <select value={mseExtra.homicide_risk} onChange={e=>setMseExtra(m=>({...m,homicide_risk:e.target.value}))} style={{...s.inp,borderColor:'rgba(255,107,107,0.3)'}}>
                    <option value="no">None</option><option value="passive">Passive thoughts</option>
                    <option value="active">Active ideation</option><option value="plan">Plan present</option>
                  </select>
                </div>
              </div>
              <div style={{...s.fg,marginTop:12}}>
                <label style={s.lbl}>Command Hallucinations</label>
                <select value={mseExtra.command_hallucinations} onChange={e=>setMseExtra(m=>({...m,command_hallucinations:e.target.value}))} style={{...s.inp,borderColor:'rgba(255,107,107,0.3)'}}>
                  <option value="no">None</option><option value="present_not_acting">Present — not acting on</option>
                  <option value="acting">Acting on commands</option>
                </select>
              </div>
            </div>

            <div style={s.fg}><label style={s.lbl}>Safety Plan / Assessment Notes</label><textarea rows={4} value={mseExtra.safety_assessment} onChange={e=>setMseExtra(m=>({...m,safety_assessment:e.target.value}))} placeholder="Crisis plan, support system, means restriction, follow-up safety arrangements..." style={s.ta}/></div>
            <div style={s.fg}><label style={s.lbl}>Clinical Assessment Notes</label><textarea rows={4} value={mseExtra.assessment_notes} onChange={e=>setMseExtra(m=>({...m,assessment_notes:e.target.value}))} placeholder="Overall clinical impression, change from baseline, response to treatment..." style={s.ta}/></div>

            <button disabled={saving} onClick={()=>save('patient_mental_status',{...mse,...mseExtra,assessment_date:new Date().toISOString(),encounter_id:sess?.encounter_id})} style={saving?s.btnOff:s.btn}>
              {saving?'Saving...':'Save Mental Status Exam → Scheduling'}
            </button>
          </div>
        )}

        {/* E&M NOTE */}
        {tab==='em' && (
          <div style={s.form}>
            <div style={s.fg}>
              <label style={s.lbl}>Primary Diagnosis (DSM-5 / ICD-10)</label>
              <div style={{display:'flex',gap:8}}>
                <input value={em.diagnosis} onChange={e=>setEm(d=>({...d,diagnosis:e.target.value}))} placeholder="F32.1 Major depressive disorder, moderate..." style={{...s.inp,flex:1}}/>
                <select onChange={e=>{if(e.target.value)setEm(d=>({...d,diagnosis:e.target.value}))}} style={{...s.inp,width:180,flex:'none'}}>
                  <option value="">Quick select...</option>
                  {DSM5_COMMON.map(d=><option key={d} value={d}>{d}</option>)}
                </select>
              </div>
            </div>
            <div style={s.row}>
              <div style={s.fg}>
                <label style={s.lbl}>E&M Code</label>
                <select value={em.em_code} onChange={e=>setEm(d=>({...d,em_code:e.target.value}))} style={s.inp}>
                  <option value="99202">99202 — New, low complexity</option>
                  <option value="99203">99203 — New, moderate complexity</option>
                  <option value="99204">99204 — New, moderate-high</option>
                  <option value="99205">99205 — New, high complexity</option>
                  <option value="99211">99211 — Established, minimal</option>
                  <option value="99212">99212 — Established, low</option>
                  <option value="99213">99213 — Established, moderate</option>
                  <option value="99214">99214 — Established, moderate-high</option>
                  <option value="99215">99215 — Established, high</option>
                  <option value="90837">90837 — Psychotherapy, 60 min</option>
                  <option value="90834">90834 — Psychotherapy, 45 min</option>
                  <option value="90832">90832 — Psychotherapy, 30 min</option>
                  <option value="90833">90833 — Psychotherapy add-on with E&M</option>
                  <option value="90847">90847 — Family therapy with patient</option>
                </select>
              </div>
              <div style={s.fg}>
                <label style={s.lbl}>Medications Reviewed</label>
                <select value={em.medications_reviewed?'yes':'no'} onChange={e=>setEm(d=>({...d,medications_reviewed:e.target.value==='yes'}))} style={s.inp}>
                  <option value="yes">Yes — reviewed and reconciled</option>
                  <option value="no">No — deferred</option>
                </select>
              </div>
            </div>
            <div style={s.fg}><label style={s.lbl}>Clinical Assessment *</label><textarea rows={6} value={em.assessment} onChange={e=>setEm(d=>({...d,assessment:e.target.value}))} placeholder="Current clinical presentation, functional status, progress vs. last visit, response to medications..." style={s.ta}/></div>
            <div style={s.fg}><label style={s.lbl}>Treatment Plan *</label><textarea rows={6} value={em.plan} onChange={e=>setEm(d=>({...d,plan:e.target.value}))} placeholder="Medication changes, therapy goals, referrals, follow-up interval, crisis resources reviewed..." style={s.ta}/></div>
            <div style={s.fg}>
              <label style={s.lbl}>Safety Plan Reviewed</label>
              <select value={em.safety_plan_reviewed?'yes':'no'} onChange={e=>setEm(d=>({...d,safety_plan_reviewed:e.target.value==='yes'}))} style={s.inp}>
                <option value="no">Not applicable this visit</option>
                <option value="yes">Yes — reviewed and updated</option>
              </select>
            </div>
            <button disabled={saving||!em.diagnosis||!em.assessment||!em.plan} onClick={()=>save('evaluation_management',{...em,encounter_id:sess?.encounter_id,insert_date:new Date().toISOString()})} style={saving||!em.diagnosis||!em.assessment||!em.plan?s.btnOff:s.btn}>
              {saving?'Saving...':'Save E&M Note → Scheduling'}
            </button>
          </div>
        )}

        {/* CARE PLAN */}
        {tab==='careplan' && (
          <div style={s.form}>
            <div style={s.row}>
              <div style={s.fg}>
                <label style={s.lbl}>Modality</label>
                <select value={cp.modality} onChange={e=>setCp(c=>({...c,modality:e.target.value}))} style={s.inp}>
                  <option>Individual therapy</option><option>Group therapy</option>
                  <option>Family therapy</option><option>Couples therapy</option>
                  <option>Medication management only</option><option>Combined therapy + medication</option>
                  <option>DBT</option><option>CBT</option><option>EMDR</option>
                  <option>Motivational interviewing</option>
                </select>
              </div>
              <div style={s.fg}>
                <label style={s.lbl}>Session Frequency</label>
                <select value={cp.frequency} onChange={e=>setCp(c=>({...c,frequency:e.target.value}))} style={s.inp}>
                  <option>Weekly</option><option>Biweekly</option><option>Monthly</option>
                  <option>PRN</option><option>Intensive outpatient (3x/week)</option>
                </select>
              </div>
            </div>
            <div style={s.fg}><label style={s.lbl}>Target Review Date</label><input type="date" value={cp.target_date} onChange={e=>setCp(c=>({...c,target_date:e.target.value}))} style={s.inp}/></div>
            <div style={s.fg}><label style={s.lbl}>Treatment Goals *</label><textarea rows={6} value={cp.goals} onChange={e=>setCp(c=>({...c,goals:e.target.value}))} placeholder="SMART goals: Specific, Measurable, Achievable, Relevant, Time-bound&#10;&#10;e.g. Patient will report depression PHQ-9 score < 10 within 8 weeks..." style={s.ta}/></div>
            <div style={s.fg}><label style={s.lbl}>Interventions *</label><textarea rows={6} value={cp.interventions} onChange={e=>setCp(c=>({...c,interventions:e.target.value}))} placeholder="CBT for cognitive distortions, behavioral activation, sleep hygiene, psychoeducation, medication adherence monitoring..." style={s.ta}/></div>
            <button disabled={saving||!cp.goals||!cp.interventions} onClick={()=>save('patient_careplan',{...cp,encounter_id:sess?.encounter_id,plan_date:new Date().toISOString()})} style={saving||!cp.goals||!cp.interventions?s.btnOff:s.btn}>
              {saving?'Saving...':'Save Care Plan → Scheduling'}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
